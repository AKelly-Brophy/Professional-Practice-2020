﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeerController : MonoBehaviour
{    void OnCollisionEnter(Collision col)
    {
        if (col.gameObject.tag == "Carrot")
        {
            Debug.Log("You ate a carrot");
            Destroy(col.gameObject);
        }
    }    
}
